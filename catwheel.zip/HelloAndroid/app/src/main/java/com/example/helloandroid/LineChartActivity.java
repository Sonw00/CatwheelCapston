package com.example.helloandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.util.ArrayList;
import java.util.List;

public class LineChartActivity extends AppCompatActivity {

    private LineChart lineChart;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_line_chart);

        lineChart = (LineChart)findViewById(R.id.chart);

        List<Entry> distanceEntry = new ArrayList<>();
        distanceEntry.add(new Entry(1,1));
        distanceEntry.add(new Entry(2,2));
        distanceEntry.add(new Entry(3,0));
        distanceEntry.add(new Entry(4,4));
        distanceEntry.add(new Entry(5,3));
        distanceEntry.add(new Entry(6,30));

        List<Entry> calorieEntry = new ArrayList<>();
        calorieEntry.add(new Entry(1,11));
        calorieEntry.add(new Entry(2,1));
        calorieEntry.add(new Entry(3,37));
        calorieEntry.add(new Entry(4,41));
        calorieEntry.add(new Entry(5,13));
        calorieEntry.add(new Entry(6,32));

        LineDataSet distanceDataSet = new LineDataSet(distanceEntry, "거리(m)");
        distanceDataSet.setLineWidth(2);
        distanceDataSet.setCircleRadius(6);
        distanceDataSet.setCircleColor(Color.parseColor("#FFA1B4DC"));
        distanceDataSet.setCircleHoleColor(Color.BLUE);
        distanceDataSet.setColor(Color.parseColor("#FFA1B4DC"));
        distanceDataSet.setDrawCircleHole(true);
        distanceDataSet.setDrawCircles(true);
        distanceDataSet.setDrawHorizontalHighlightIndicator(false);
        distanceDataSet.setDrawHighlightIndicators(false);
        distanceDataSet.setDrawValues(true);


        LineDataSet calorieDataSet = new LineDataSet(calorieEntry, "소모 칼로리(kcal)");
        calorieDataSet.setLineWidth(2);
        calorieDataSet.setCircleRadius(6);
        calorieDataSet.setCircleColor(Color.rgb(251,99,118));
        calorieDataSet.setCircleHoleColor(Color.RED);
        calorieDataSet.setColor(Color.rgb(251,99,118));
        calorieDataSet.setDrawCircleHole(true);
        calorieDataSet.setDrawCircles(true);
        calorieDataSet.setDrawHorizontalHighlightIndicator(false);
        calorieDataSet.setDrawHighlightIndicators(false);
        calorieDataSet.setDrawValues(true);

        ArrayList<LineDataSet> dataSets = new ArrayList<>();
        dataSets.add(calorieDataSet);
        dataSets.add(distanceDataSet);

        LineData data = new LineData((ArrayList) dataSets);
        lineChart.setData(data);

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setTextColor(Color.BLACK);
        xAxis.setSpaceMax(1f);
        xAxis.setSpaceMin(1f);
        xAxis.setValueFormatter(new IndexAxisValueFormatter());
        xAxis.enableGridDashedLine(8,24,0);

        YAxis yLAxis = lineChart.getAxisLeft();
        yLAxis.setTextColor(Color.BLACK);

        YAxis yRAxis = lineChart.getAxisRight();
        yRAxis.setDrawLabels(false);
        yRAxis.setDrawAxisLine(false);
        yRAxis.setDrawGridLines(false);

        Description description = new Description();
        description.setText("");

        lineChart.setDoubleTapToZoomEnabled(false);
        lineChart.setDrawGridBackground(false);
        lineChart.setDescription(description);
        lineChart.animateY(2000, Easing.EaseInCubic);
        lineChart.setScaleEnabled(false);
        lineChart.moveViewToX(data.getEntryCount());
        lineChart.invalidate();





    }
}