package com.example.helloandroid;

public class DetailedData {

    private String run_time;
    private String start_time;
    private String end_time;
    private float everage_speed;
    private int calorie;
    private float revolutions;
    private int reward;
}
