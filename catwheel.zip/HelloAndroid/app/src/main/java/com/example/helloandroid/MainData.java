package com.example.helloandroid;

public class MainData {

    private String cw_name;
    private String cw_content;


    private int run_time;
    private String start_time;
    private String end_time;
    private float distance;
    private int calorie;
    private float revolutions;
    private int reward;

    public MainData(String cw_name, String cw_content) {
        this.cw_name = cw_name;
        this.cw_content = cw_content;

    }

    public String getCw_name() {
        return cw_name;
    }

    public void setCw_name(String cw_name) {
        this.cw_name = cw_name;
    }

    public String getCw_content() {
        return cw_content;
    }

    public void setCw_content(String cw_content) {
        this.cw_content = cw_content;
    }


    public MainData(String cw_name, String cw_content,int run_time, String start_time, String end_time, float distance, int calorie, float revolutions, int reward) {
        this.cw_name = cw_name;
        this.cw_content = cw_content;
        this.run_time = run_time;
        this.start_time = start_time;
        this.end_time = end_time;
        this.distance = distance;
        this.calorie = calorie;
        this.revolutions = revolutions;
        this.reward = reward;
    }

    public int getRun_time() {
        return run_time;
    }

    public void setRun_time(int run_time) {
        this.run_time = run_time;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public float getDistance() {
        return distance;
    }

    public void setDistance(float distance) {
        this.distance = distance;
    }

    public int getCalorie() {
        return calorie;
    }

    public void setCalorie(int calorie) {
        this.calorie = calorie;
    }

    public float getRevolutions() {
        return revolutions;
    }

    public void setRevolutions(float revolutions) {
        this.revolutions = revolutions;
    }

    public int getReward() {
        return reward;
    }

    public void setReward(int reward) {
        this.reward = reward;
    }
}
