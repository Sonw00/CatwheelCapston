package com.example.helloandroid;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class InformationActivity extends AppCompatActivity {
    public ArrayList<MainData> arrayList;
    private DetailedAdapter detailedAdapter;
    public RecyclerView recyclerView;
    private LinearLayoutManager linearLayoutManager;
    private MainActivity mainActivity;
    private String name;
    private String content;
    private Intent intent;
    private int number;
    private TextView tvName,tvContent;
    private ArrayAdapter<CharSequence> adapter = null;
    private Spinner spinner = null;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

        recyclerView = (RecyclerView)findViewById(R.id.rvDetail);
        linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        intent = getIntent();

        arrayList = new ArrayList<>();
        detailedAdapter = new DetailedAdapter(arrayList);
        recyclerView.setAdapter(detailedAdapter);

        adapter = ArrayAdapter.createFromResource(this,R.array.ㅡ, android.R.layout.simple_spinner_dropdown_item);
        spinner = findViewById(R.id.spinner);
        spinner.setAdapter(adapter);

        Button btn = (Button) findViewById(R.id.addButton);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainData mainData = new MainData("캣휠","작동중",1,"1:21","3:21", (float) 3.1,32,(float)3.1,1);
                arrayList.add(mainData);

                detailedAdapter.notifyDataSetChanged();

            }
        });


        /*number = intent.getIntExtra("number",-1);
        name = intent.getStringExtra("name");
        tvName = findViewById(R.id.attName);
        tvContent = findViewById(R.id.attContent);
        tvName.setText(name);
        tvContent.setText(number);*/
        //initToolbar();

    }
    private void initToolbar() {
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        //getSupportActionBar().setTitle("About");
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
       // Tools.setSystemBarColor(this, android.R.color.holo_red_dark);


    }
}