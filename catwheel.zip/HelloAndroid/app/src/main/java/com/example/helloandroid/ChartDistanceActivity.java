package com.example.helloandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import java.util.ArrayList;

public class ChartDistanceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart_distance);

        Intent intent = getIntent();

        BarChart barChart = findViewById(R.id.bar_chart);
        BarDataSet barDataSet1 = new BarDataSet(data1(),"Data1"); // 데이터 생성
        BarData barData = new BarData(); // 바 데이터 생성
        barData.addDataSet(barDataSet1); // 바 데이터에 데이터셋 추가
        barChart.setData(barData); //바차트에 바데이터 등록
    }

    private ArrayList<BarEntry> data1(){
        ArrayList<BarEntry> dataList = new ArrayList<>();

        dataList.add(new BarEntry(0,3));
        dataList.add(new BarEntry(1,6));
        dataList.add(new BarEntry(2,10));
        dataList.add(new BarEntry(3,15));

        return dataList;
    }
}