package com.example.helloandroid;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DetailedAdapter extends RecyclerView.Adapter<DetailedAdapter.CustomViewHolder> {
    private ArrayList<MainData> arrayList;
    Date date;

    public DetailedAdapter(ArrayList<MainData> arrayList) {
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public DetailedAdapter.CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.detail_item_list,parent,false);
        CustomViewHolder holder = new CustomViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull DetailedAdapter.CustomViewHolder holder, int position) {
        long now = System.currentTimeMillis();
        date = new Date(now);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        holder.tv_distance.setText(String.valueOf(arrayList.get(position).getDistance()));
        holder.tv_runtime.setText(arrayList.get(position).getRun_time());
        holder.tv_date.setText(sdf.format(date));

        holder.itemView.setTag(position);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String curDistance = holder.tv_distance.getText().toString();
                String curRuntime = holder.tv_runtime.getText().toString();

                Intent intent = new Intent(view.getContext(),DetailedInformationActivity.class);

                view.getContext().startActivity(intent);

            }
        });
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                remove(holder.getAdapterPosition());
                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return (null != arrayList ? arrayList.size() : 0);
    }

    public void remove(int position){
        try{
            arrayList.remove(position);
            notifyItemRemoved(position);

        } catch(IndexOutOfBoundsException ex){
            ex.printStackTrace();
        }
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {

        protected TextView tv_distance;
        protected TextView tv_date;
        protected TextView tv_runtime;
        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            this.tv_distance = (TextView) itemView.findViewById(R.id.tvDistance);
            this.tv_date = (TextView) itemView.findViewById(R.id.tvDate);
            this.tv_runtime = (TextView) itemView.findViewById(R.id.tvRuntime);
        }
    }
}
