package com.example.helloandroid;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.CustomViewHolder> {

    private ArrayList<MainData> arrayList;

    public MainAdapter(ArrayList<MainData> arrayList) {
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public MainAdapter.CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list,parent, false);
        CustomViewHolder holder = new CustomViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MainAdapter.CustomViewHolder holder, int position) {
        holder.cw_name.setText(arrayList.get(position).getCw_name());
        holder.cw_content.setText(arrayList.get(position).getCw_content());

        holder.itemView.setTag(position);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = holder.getAdapterPosition();
               //String curName = holder.cw_name.getText().toString();
                //Toast.makeText(view.getContext(), curName, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(view.getContext(),InformationActivity.class);
                //intent.putExtra("Run_time",arrayList.get(pos).getRun_time());
                //intent.putExtra("Start_time",arrayList.get(pos).getStart_time());
                //intent.putExtra("EndTime",arrayList.get(pos).getEnd_time());

                view.getContext().startActivity(intent);
            }
        });
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                remove(holder.getAdapterPosition());
                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return (null != arrayList ? arrayList.size() : 0);
    }

    public void remove(int position){
        try{
            arrayList.remove(position);
            notifyItemRemoved(position);

        } catch(IndexOutOfBoundsException ex){
            ex.printStackTrace();
        }
    }
    public class CustomViewHolder extends RecyclerView.ViewHolder {

        protected TextView cw_name;
        protected TextView cw_content;
        //protected LinearLayout item_Element;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            this.cw_name = (TextView) itemView.findViewById(R.id.cw1Name);
            this.cw_content = (TextView) itemView.findViewById(R.id.cw1);
            //item_Element = itemView.findViewById(R.id.cwItem);
            itemView.setClickable(true);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    int pos = getAdapterPosition();
                    //Intent intent = new Intent(mContext,InformationActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    //Intent intent = new Intent(view.getContext(),InformationActivity.class);
                    //intent.putExtra("number",pos);
                    //intent.putExtra("name",cw_name.getText());
                    //view.getContext().startActivity(intent);
                    //mContext.startActivity(intent);
                }
            });

        }
    }
}
