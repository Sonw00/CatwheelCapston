package com.example.helloandroid;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public ArrayList<MainData> arrayList;
    private InformationActivity informationActivity;
    private DetailedAdapter detailedAdapter;
    private MainAdapter mainAdapter;
    private RecyclerView recyclerView;
    private LinearLayoutManager linearLayoutManager;
    private Intent intent;
    private CardView cvDistance,cvCalorie;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //intent = new Intent(this, InformationActivity.class);

        recyclerView = (RecyclerView) findViewById(R.id.rv);
        linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        informationActivity = new InformationActivity();

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);

        arrayList = new ArrayList<>();
        mainAdapter = new MainAdapter(arrayList);
        detailedAdapter = new DetailedAdapter(arrayList);
        recyclerView.setAdapter(mainAdapter);
        //informationActivity.recyclerView.setAdapter(detailedAdapter);

        Button btn_add = (Button) findViewById(R.id.btn_add);

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainData mainData = new MainData("캣휠","작동중",1,"1:21","3:21", (float) 3.1,32,(float)3.1,1);
                arrayList.add(mainData);
                mainAdapter.notifyDataSetChanged();
                //detailedAdapter.notifyDataSetChanged();

            }
        });

        cvCalorie = (CardView) findViewById(R.id.cvCalorie);
        cvDistance = (CardView) findViewById(R.id.cvDiatance);

        cvCalorie.setClickable(true);
        cvDistance.setClickable(true);
        cvCalorie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LineChartActivity.class);
                startActivity(intent);
            }
        });
        cvDistance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ChartDistanceActivity.class);
                startActivity(intent);
            }
        });

    }
}